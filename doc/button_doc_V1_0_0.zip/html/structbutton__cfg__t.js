var structbutton__cfg__t =
[
    [ "gpio_pin", "structbutton__cfg__t.html#aac8f822b804adacb929e3d7c4f611ce4", null ],
    [ "lpf_en", "structbutton__cfg__t.html#ac49036ec4527cb47764b3c2773c036af", null ],
    [ "lpf_fc", "structbutton__cfg__t.html#af336b4180fcb3eb013739c53bf76aa56", null ],
    [ "polarity", "structbutton__cfg__t.html#a3f19e038da9911a9f6ca761fa132b8f7", null ]
];