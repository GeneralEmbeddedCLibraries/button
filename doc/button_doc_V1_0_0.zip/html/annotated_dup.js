var annotated_dup =
[
    [ "button_cfg_t", "structbutton__cfg__t.html", "structbutton__cfg__t" ],
    [ "button_data_t", "structbutton__data__t.html", "structbutton__data__t" ]
];