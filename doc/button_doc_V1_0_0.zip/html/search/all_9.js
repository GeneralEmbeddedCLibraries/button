var searchData=
[
  ['released_51',['released',['../structbutton__data__t.html#a3f82c4abac2dae83985448f3a8da6897',1,'button_data_t']]]
];
