var searchData=
[
  ['idle_79',['idle',['../structbutton__data__t.html#a950d1a10daced33f74bea2c29f940fd1',1,'button_data_t']]]
];
