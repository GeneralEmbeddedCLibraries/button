var searchData=
[
  ['state_86',['state',['../structbutton__data__t.html#a93887ec25bd14551376963d8b2ee87b6',1,'button_data_t']]]
];
