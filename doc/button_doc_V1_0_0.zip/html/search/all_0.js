var searchData=
[
  ['active_0',['active',['../structbutton__data__t.html#a115bd7d3cb5a4f4283900f458ed62a05',1,'button_data_t']]]
];
