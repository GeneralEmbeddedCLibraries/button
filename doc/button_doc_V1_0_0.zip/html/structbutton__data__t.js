var structbutton__data__t =
[
    [ "active", "structbutton__data__t.html#a115bd7d3cb5a4f4283900f458ed62a05", null ],
    [ "cur", "structbutton__data__t.html#a4b1c0faae6ce3fb65f97c972c2031cfa", null ],
    [ "filt", "structbutton__data__t.html#a23467c4480032178779266ef522a72dc", null ],
    [ "idle", "structbutton__data__t.html#a950d1a10daced33f74bea2c29f940fd1", null ],
    [ "pressed", "structbutton__data__t.html#a279da6114b0f78ca5c15aa5972e267f7", null ],
    [ "prev", "structbutton__data__t.html#a3025158893d0ce1f3bf14b93919c5d42", null ],
    [ "released", "structbutton__data__t.html#a3f82c4abac2dae83985448f3a8da6897", null ],
    [ "state", "structbutton__data__t.html#a93887ec25bd14551376963d8b2ee87b6", null ],
    [ "time", "structbutton__data__t.html#a6b987d4cd942295206c541ee9eacbe93", null ]
];